import * as ActionTypes from './actionTypes.js';

const init = {
    accountInfo: {}
}

export default function messageReducers(state = init, action) {
    switch (action.type) {
        case ActionTypes.GET_ACCOUNT_DATA_SUCCESS:
            return _.extend({}, state,  {accountInfo:action.payload});
        case ActionTypes.GET_ACCOUNT_DATA_FAIL:
            return _.extend({}, state, { accountInfo: {} });
        default:
            return state;
    }
}