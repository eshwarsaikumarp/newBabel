import * as ActionTypes from './actionTypes.js';


export function updateComponentState(type, payload){
    return {type, payload};
}

export function fetchAccountNumber(accnumber){
    return (dispatch) => {
        let accountNumber = parseInt(accnumber); 
        let obj = data.filter((item) => item.accountNumber === accountNumber); 
      if(obj.length > 0){
          dispatch(updateComponentState(ActionTypes.GET_ACCOUNT_DATA_SUCCESS, obj[0]))
      }
        else{
          dispatch(updateComponentState(ActionTypes.GET_ACCOUNT_DATA_FAIL, ''));
          alert("Enter Valid Account Number")
      }
        
    }
}
