import React, {Component} from 'react';
import {connect} from 'react-redux';
import {bindActionCreators} from 'redux';
import { Button } from 'react-bootstrap';
import _ from 'lodash';
import * as mainActions from './action';

import Banner from '../banner/index'

import '../../../node_modules/bootstrap/dist/css/bootstrap.min.css';
import '../../../node_modules/ag-grid/dist/styles/ag-grid.css';
import '../../../node_modules/ag-grid/dist/styles/theme-fresh.css';

import './style.css'


class MainController extends Component{
    constructor(props){
        super(props);
        this.state = {
                        inputValue:'',
                        show:false,
                        selectedClass:false,
                        leaseClose:true
                     }
        this.handleInput = this.handleInput.bind(this);
        this.handleButton = this.handleButton.bind(this);
        this.handleShow = this.handleShow.bind(this);
        this.handleClose = this.handleClose.bind(this);
        this.addClass = this.addClass.bind(this);
        this.leaseClose = this.leaseClose.bind(this);
        this.leaseShow = this.leaseClose.bind(this);
    }

    
    handleClose() {
        this.setState({ show: false });
      }
    
    handleShow() {
        this.setState({ show: true });
      }
    
    handleInput(e) {
      const val = e.target.value;
      this.setState({ inputValue: val})
    }

    handleButton() {
      const inputValue = this.state.inputValue;
      this.props.actions.fetchAccountNumber(inputValue)
    }

    addClass() {
        this.setState({
            selectedClass: true
        })
    }

    leaseClose(){
        this.setState({
            leaseClose:!this.state.leaseClose
        })
    }

    leaseShow(){
        this.setState({
            leaseClose:true
        })
    }

    render(){
        let {accountInfo} = this.props;
        const warnings=accountInfo.warnings;
        return (
			<div>
                <nav>
                    <div className="main_container">
                        <div className="row">
                            <ul className="mainNav col-md-7">
                                <li onClick={this.leaseShow}><a href="#">Lease</a></li>
                                <li><a href="#">Asset</a></li>
                                <li><a href="#">Quote</a></li>
                                <li><a href="#">Utility</a></li>
                                <li><a href="#">My Norad</a></li>
                                <li><a href="#">RMKTG</a></li>
                                <li><a href="#">Pink Tools</a></li>
                                <li><a href="#">Switch</a></li>
                            </ul>
                        
                            <div className="col-md-5 fl_right">
                                <label>Account sched</label>
                                <input type="text" onChange={this.handleInput} value={this.state.inputValue} />
                                <Button className="btns" bsSize="xsmall" onClick={this.handleButton}>Go</Button>
                                <Button className="btns" bsSize="xsmall">Next</Button>                            
                            </div>
                        </div>
                    </div>
                </nav>
             
                <main>
                    {(Object.keys(accountInfo).length > 0) ? <Banner data={accountInfo}/> : null}
                </main>
            </div>
        )
    }
}


function mapStateToProps(state, oldProps){
    return {
        accountInfo: state.mainReducers.accountInfo

    }
}

function mapDispatchToProps(dispatch){
    return {
        actions: bindActionCreators(mainActions, dispatch)
    }
}


export default connect(mapStateToProps, mapDispatchToProps)(MainController);