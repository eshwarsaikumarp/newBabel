import React, { Component } from 'react'
import { Button, Modal } from 'react-bootstrap';


class Popup extends Component {
    constructor(props){
        super(props);
       
    }



    render () {
        const warnings = this.props.data;
        return (
            <div>
                <Modal>
                    <Modal.Dialog  id="shadow">
                        <Modal.Header>
                            <Modal.Title>Flags and Warnings <span className="closeIcon" >X</span></Modal.Title>
                        </Modal.Header>
                    
                        <Modal.Body>    
                            {Object.keys(warnings).map((items,index) =>
                                <div key={index} className="focusedItem" tabIndex={index}><span id="arw">&#x27A4;</span><span  className="popupContent" key={index}>{warnings[items]}</span></div>
                            )}
                        </Modal.Body>
                    
                        <Modal.Footer>
                            <Button >Close</Button>
                        </Modal.Footer>
                  </Modal.Dialog>
                </Modal>     
            </div>
        )
    }
}

export default Popup