import React, {Component} from 'react';
import {connect} from 'react-redux';
import _ from 'lodash';
import {bindActionCreators} from 'redux';
import { Button } from 'react-bootstrap';

import Modal from '../modal/index'
import './style.css'

class Banner extends Component {
    constructor(props){
        super(props);
        this.state = {
            showModal:false
        }
        this.handleShow = this.handleShow.bind(this);
    }

    handleShow(){
        this.setState({
            showModal:true
        })
    }
    render () {
        const accountInfo = this.props.data;
        const warnings = this.props.data.warnings;
        console.log("myyWarnings",warnings)
        return (
            <div>
               <div className="banner">
                    <div className="main_container">
                        <div className="row">
                            <div className="col-md-9">
                                <div className="row">
                                    <div className="col-md-4">
                                        <p>{accountInfo.company}</p>
                                        <p className="row">
                                            <div className="col-md-7">AMO / EG Owner:</div>
                                            <div className="col-md-5">{accountInfo.owner}</div></p>
                                        <p className="row">
                                            <div className="col-md-7">Collat Desc:</div>
                                            <div className="col-md-5">{accountInfo.collatDesc}</div></p>
                                        <p className="row">
                                            <div className="col-md-7">Program/AssetClass:</div>
                                            <div className="col-md-5">{accountInfo.program}</div></p>
                                    </div>

                                    <div className="col-md-4">
                                        <p className="row">
                                            <div className="col-md-7">Tax Code:</div>
                                            <div className="col-md-5">{accountInfo.taxCode}</div></p>
                                        <p className="row">
                                          <div className="col-md-7">PO Type:</div>
                                          <div className="col-md-5">{accountInfo.poType}</div></p>
                                        <p className="row">
                                            <div className="col-md-7">Ext Ref z/Conv Ind:</div>
                                            <div className="col-md-5">{accountInfo.ref}</div></p>
                                        <p className="row">
                                             <div className="col-md-7">Location:</div>
                                             <div className="col-md-5">{accountInfo.location}</div></p>
                                    </div>

                                    <div className="col-md-4">
                                        <p className="row">
                                            <div className="col-md-5">Cust Name:</div>
                                            <div className="col-md-7">{accountInfo.custName}</div></p>
                                        <p className="row">
                                            <div className="col-md-4">Contact:</div>
                                            <div className="col-md-8">{accountInfo.contact}</div></p>
                                        <p className="row">
                                            <div className="col-md-4">Phone:</div>
                                            <div className="col-md-8">{accountInfo.phone}</div></p>
                                        <p className="row">
                                            <div className="col-md-4">Fax:</div>
                                            <div className="col-md-8">{accountInfo.fax}</div></p>
                                    </div>
                                </div>
                            </div>
                
                            <div className="col-md-3 mainScroll">
                                <div id="scroll" >
                                    {Object.keys(warnings).map((items,index) =>
                                        <div id="content" key={index}>{warnings[items]}</div>
                                    )}
                                </div>        
                                <Button className="popup_btn" bsSize="small" onClick={this.handleShow}>?</Button>
                            </div>
                        </div>
                    </div>
                </div>
                {this.state.showModal ? <Modal data={accountInfo.warnings} /> : null}
            </div>
        )
    }
}

export default Banner