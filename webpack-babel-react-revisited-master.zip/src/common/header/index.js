import React, { Component } from 'react';
import { render } from 'react-dom';

import './style.css';

export default class Header extends Component {
  render() {
    return (
     
          <header>
            <div className="main_container">
              <h4>WELLSFARGO</h4>
            </div>
          </header>        
      
    );
  }
}
