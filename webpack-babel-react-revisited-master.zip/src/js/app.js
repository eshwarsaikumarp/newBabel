import React, { Component } from 'react';
import { render } from 'react-dom';
import Header from '../common/header/index';

import ReactDOM from 'react-dom';
import {Provider} from "react-redux";
import { Router, Route, browserHistory, IndexRoute, Redirect } from "react-router";
import store from "../components/store.js";

import MainComponent from "../components/main/index";

import '../css/style.css';

export default class Hello extends Component {
  constructor(props) {
    super(props);
}
  render() {
    return (
      <div>
          <Header /> 
          {this.props.children}            
      </div>
    );
  }
}

ReactDOM.render(<Provider store={store}>
  <Router history={browserHistory}>
      <Route path="/" component={Hello}>
          <Route path="employee" component={MainComponent}></Route>
          <IndexRoute component={MainComponent} />
      </Route>
  </Router>
</Provider>, document.getElementById("app"));