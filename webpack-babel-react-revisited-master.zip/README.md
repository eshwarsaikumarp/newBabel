# Setting up Webpack, Babel and React from scratch, revisited

This is example repo for webpack/babel/react tutorial:

[https://stanko.github.io/webpack-babel-react-revisited](https://stanko.github.io/webpack-babel-react-revisited)
